# -*- coding: utf-8 -*-
from .version import __version__, __version_info__
from .exceptions import TextmagicException

