# -*- coding: utf-8 -*-
class TextmagicException(Exception):
    pass